import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Send email to the specified address
    const emailData = {
      to: "ilove265615@yahoo.com.tw",
      subject: "新的刷卡換現金諮詢請求",
      html: `
        <h1>新的刷卡換現金諮詢請求</h1>
        <p><strong>姓名:</strong> ${data.name}</p>
        <p><strong>電話:</strong> ${data.phone}</p>
        <p><strong>金額:</strong> ${data.amount || "未指定"}</p>
        <p><strong>偏好聯絡方式:</strong> ${data.preferredContact === "line" ? "LINE" : "電話"}</p>
        <p><strong>留言:</strong> ${data.message || "無"}</p>
        <p><strong>提交時間:</strong> ${new Date().toLocaleString("zh-TW", { timeZone: "Asia/Taipei" })}</p>
      `,
    }

    // In a real implementation, you would use a service like Nodemailer, SendGrid, etc.
    // For this example, we'll just simulate a successful email send
    console.log("Form submission:", emailData)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Form submission error:", error)
    return NextResponse.json({ error: "Failed to process form submission" }, { status: 500 })
  }
}

